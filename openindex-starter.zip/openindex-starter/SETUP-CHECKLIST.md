# Setup checklist

- [ ] Create a **public** GitHub repository.
- [ ] Upload the extracted starter files, preserving folders.
- [ ] Open the repository in GitHub Codespaces.
- [ ] Run `npx wrangler@latest login`.
- [ ] Run `npx wrangler@latest d1 create openindex-db`.
- [ ] Paste the returned ID into `wrangler.jsonc`.
- [ ] Run `npx wrangler@latest d1 execute openindex-db --remote --file=./schema.sql`.
- [ ] Run `npx wrangler@latest deploy` and save the Worker URL.
- [ ] Generate a secret and set it with `npx wrangler@latest secret put INGEST_SECRET`.
- [ ] Add `SEARCH_API_URL` and `INGEST_SECRET` under GitHub repository Actions secrets.
- [ ] Enable Actions and manually run **Crawl and update OpenIndex**.
- [ ] Change the example crawler identity in `crawler/crawl.py` before wider crawling.
