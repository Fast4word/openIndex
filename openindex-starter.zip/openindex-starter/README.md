# OpenIndex — Chromebook-friendly independent search starter

This is a small, genuinely independent search-index prototype. It does **not** call Google, Bing, Mojeek, Mwmbl or another search-results API. It crawls pages itself, stores extracted text in Cloudflare D1, and searches that data with SQLite FTS5.

## The zero-cost architecture

- **Chromebook:** browser only. No local Linux, Python or Node installation is required.
- **GitHub Codespaces:** optional browser-based cloud terminal for the one-time deployment commands.
- **GitHub Actions:** runs the Python crawler on hosted GitHub machines. The repository must be public to use standard hosted runners without consuming private-repository minutes.
- **Cloudflare Worker:** serves the search website and JSON API.
- **Cloudflare D1:** stores document metadata, extracted text, the crawl queue and the FTS5 search index.

The free tier is for an experiment, not a Google-scale service. D1 Free currently allows a 500 MB database (5 GB total per account); Workers Free currently allows 100,000 requests/day and 10 ms CPU time per request. Check the current provider limits before relying on them for a business.

## 1. Create a public GitHub repository

1. On your Chromebook, open <https://github.com/new>.
2. Create a **Public** repository, for example `openindex`.
3. Download `openindex-starter.zip` to your Chromebook.
4. In the new repository, choose **Add file → Upload files**, upload the ZIP file, and commit it. This is just a temporary transfer step; the ZIP will be removed from the repository during setup.

The crawler source will be public. Do **not** put passwords, API tokens or private information in the files.

## 2. Open the repository in Codespaces

1. In the repository, click **Code** → **Codespaces** → **Create codespace on main**.
2. Wait for the browser editor to open. This is a remote development computer; it does not require Linux on your Chromebook.
3. Open **Terminal → New Terminal**.
4. Confirm the files are in the current directory. If they were uploaded into a subfolder, `cd` into that folder.

GitHub Free personal accounts currently include a limited monthly Codespaces allowance. Codespaces is only needed for setup and deployment; the deployed service and crawler do not run inside your Codespace.

## 3. Create a Cloudflare D1 database

1. Create or sign into a free account at <https://dash.cloudflare.com/>.
2. In the Codespaces terminal, run:

   ```bash
   npx wrangler@latest login
   ```

   Follow the browser authentication instructions.

3. Create the database:

   ```bash
   npx wrangler@latest d1 create openindex-db
   ```

4. The command prints a `database_id`. Open `wrangler.jsonc` in the browser editor and replace `REPLACE_WITH_D1_DATABASE_ID` with the real ID. Save the file.
5. Apply the schema:

   ```bash
   npx wrangler@latest d1 execute openindex-db --remote --file=./schema.sql
   ```

This creates the documents table, crawl queue, FTS5 index and triggers.

## 4. Deploy the search website and API

In the Codespaces terminal:

```bash
npx wrangler@latest deploy
```

Wrangler prints a public URL similar to `https://openindex-search.YOUR-SUBDOMAIN.workers.dev`. Open it. You should see the OpenIndex search page.

Create a strong ingestion secret in the Codespaces terminal:

```bash
python -c "import secrets; print(secrets.token_urlsafe(40))"
```

Copy the generated value somewhere private temporarily. Then run:

```bash
npx wrangler@latest secret put INGEST_SECRET
```

Paste the same generated value when prompted. This secret protects the endpoints used by the crawler to add URLs and documents. Never commit it to GitHub.

## 5. Connect the GitHub crawler

In your GitHub repository:

1. Open **Settings → Secrets and variables → Actions**.
2. Choose **New repository secret** and create:
   - `SEARCH_API_URL` = the full Worker URL from step 4, without a trailing slash.
   - `INGEST_SECRET` = the same private secret you set with `wrangler secret put`.
3. Before the first crawl, edit `crawler/crawl.py` and replace the example `USER_AGENT` value with your public repository URL and a real contact address. This lets website operators identify and contact your crawler.
4. Open **Actions** and enable workflows if GitHub asks.
5. Select **Crawl and update OpenIndex** → **Run workflow**.
6. Open the run and inspect its log. It should submit seed URLs, crawl a small batch, and report how many pages it indexed.
7. Visit your Worker URL and search for a word from a crawled page.

The workflow then runs every three hours. GitHub scheduled workflows can be delayed. In public repositories, GitHub may disable scheduled workflows after 60 days without repository activity, so check the Actions tab occasionally.

## 6. Change and grow the starting coverage

Edit `seeds.txt` to add or remove starting pages. Each seed should be one HTTP or HTTPS URL per line. The crawler discovers links beyond those starting points, including links on other domains.

The initial crawler is deliberately conservative:

- 24 pages maximum per scheduled run.
- At most two selected URLs per domain in a batch.
- A default two-second delay between requests to the same host, or longer if the site's `Crawl-delay` says so.
- Checks `robots.txt` before fetching pages; it fails closed if robots retrieval fails or is forbidden.
- Ignores URL query strings to avoid tracking and search-result traps.
- Skips common binary file types; this version indexes HTML and XML sitemaps, not PDF files.
- Stores extracted text for ranking but shows only short snippets and links in search results.
- Re-crawls successfully indexed URLs after about 30 days.

Before enabling a broad crawl, replace the example crawler identity in `crawler/crawl.py` with your project URL and a real contact address. Respect each site's terms, robots policy, rate limits and takedown requests. `robots.txt` is a crawl signal, not a licence to republish copyrighted content. Keep results as links with short, query-relevant snippets rather than republishing full pages.

## 7. What this version can and cannot do

**It can:** crawl a growing web graph from your own seed list; maintain its own queue and searchable index; search its own stored content; expose a public search UI and JSON endpoint (`/api/search?q=...`).

**It cannot:** create a Google-sized index for free. The free D1 database is only 500 MB, the crawler is intentionally slow, and GitHub scheduled workflows are not a guaranteed always-on crawler. Treat the first milestone as a few thousand to tens of thousands of pages, not the entire internet.

Search uses SQLite FTS5/BM25 relevance with higher weighting for title matches. It is a useful baseline, not yet a sophisticated web-ranking system. A later version could add anchor text, link graph signals, language detection, canonical URL handling, spam controls, PDF extraction and incremental sitemap scheduling.

## Troubleshooting

- **`REPLACE_WITH_D1_DATABASE_ID` error:** confirm you copied the full ID returned by `wrangler d1 create` into `wrangler.jsonc`.
- **`no such table: documents` or FTS error:** re-run the schema command from step 3.
- **Crawler returns 401:** `INGEST_SECRET` in GitHub repository secrets must exactly match the Worker secret.
- **Crawler cannot reach the API:** check `SEARCH_API_URL`; it should be the Worker root URL, without `/api` and without a trailing slash.
- **No pages indexed:** inspect the Actions log. Sites may disallow crawling, return non-HTML, block automated requests, or have little extractable text. Add other seed sites that permit crawling.
- **Codespaces allowance exhausted:** close unused Codespaces and continue when the monthly allowance resets, or use a separate browser-based cloud IDE. The scheduled crawler runs independently in GitHub Actions.

## Useful endpoints

- `/` — search website
- `/health` — health check
- `/api/stats` — indexed page count
- `/api/search?q=your+query` — public search API

Internal crawler endpoints require the `INGEST_SECRET` bearer token and should not be exposed to users.
